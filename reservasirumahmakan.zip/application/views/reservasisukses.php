<script type="text/javascript">
function jsFunction(){
alert('Proses Reservasi Sukses, Silahkan Cek Status Reservasi Secara Berkala');
window.location.href = ".";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
