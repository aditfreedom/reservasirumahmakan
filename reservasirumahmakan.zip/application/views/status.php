<script type="text/javascript">
function jsFunction(){
alert('Silahkan Menghubungi Administrator (0823-6010-3910) Untuk Approval');
window.location.href = ".";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
