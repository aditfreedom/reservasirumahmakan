<script type="text/javascript">
function jsFunction(){
alert('Pendaftaran Ditolak, Silahkan Mendaftarkan Akun Dengan Benar!');
window.location.href = ".";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
