<script type="text/javascript">
function jsFunction(){
alert('Sukses');
window.location.href = ".";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
