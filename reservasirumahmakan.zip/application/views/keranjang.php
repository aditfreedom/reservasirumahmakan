<script type="text/javascript">
function jsFunction(){
alert('Sudah Masuk Dalam Keranjang');
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
