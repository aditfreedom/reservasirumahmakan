
    <?php foreach ($tb_rm as $rm) : ?>
      <div class="form-group" hidden>
        <input type="text" name="nama_rm" class="form-control" value="<?php echo $rm->nama_rm;?>">
        </div>
        <?php endforeach ;?>
