<script type="text/javascript">
function jsFunction(){
alert('Akun Telah Disuspend, Silahkan Hubungi (0823-6010-3910) Administrator');
window.location.href = ".";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
