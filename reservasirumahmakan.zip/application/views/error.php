<script type="text/javascript">
function jsFunction(){
alert('Username Dan Password Salah!');
window.location.href = ".";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
