<script type="text/javascript">
function jsFunction(){
alert('No HP Sudah Pernah Terdaftar');
window.location.href = ".";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
